"""Storage client para Claim Check Pattern"""

from app.storage.storage_client import StorageClient, storage_client

__all__ = ["StorageClient", "storage_client"]
