"""Módulo core dos workers"""
