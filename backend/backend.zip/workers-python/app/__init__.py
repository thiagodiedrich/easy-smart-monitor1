"""Python Workers para processamento de telemetria do Kafka"""

__version__ = "1.1.0"
